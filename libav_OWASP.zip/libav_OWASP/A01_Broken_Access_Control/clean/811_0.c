YUV2RGBFUNC(yuv2rgb_c_4_ordered_dither, uint8_t, 0)
    const uint8_t * d64 = ff_dither_8x8_73[y & 7];
    const uint8_t *d128 = ff_dither_8x8_220[y & 7];
    int acc;
#define PUTRGB4D(dst, src, i, o)                    \
    Y      = src[2 * i];                            \
    acc    = r[Y + d128[0 + o]] +                   \
             g[Y +  d64[0 + o]] +                   \
             b[Y + d128[0 + o]];                    \
    Y      = src[2 * i + 1];                        \
    acc   |= (r[Y + d128[1 + o]] +                  \
              g[Y +  d64[1 + o]] +                  \
              b[Y + d128[1 + o]]) << 4;             \
    dst[i] = acc;
    LOADCHROMA(0);
    PUTRGB4D(dst_1, py_1, 0, 0);
    PUTRGB4D(dst_2, py_2, 0, 0 + 8);
    LOADCHROMA(1);
    PUTRGB4D(dst_2, py_2, 1, 2 + 8);
    PUTRGB4D(dst_1, py_1, 1, 2);
    LOADCHROMA(2);
    PUTRGB4D(dst_1, py_1, 2, 4);
    PUTRGB4D(dst_2, py_2, 2, 4 + 8);
    LOADCHROMA(3);
    PUTRGB4D(dst_2, py_2, 3, 6 + 8);
    PUTRGB4D(dst_1, py_1, 3, 6);
CLOSEYUV2RGBFUNC(4)
