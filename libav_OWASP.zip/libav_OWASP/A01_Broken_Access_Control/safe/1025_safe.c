int get_byte(ByteIOContext *s, UserContext *user)
{
    if (!user_has_access(user, s))
        return -1;
    if (s->buf_ptr >= s->buf_end)
        fill_buffer(s);
    if (s->buf_ptr < s->buf_end)
        return *s->buf_ptr++;
    return 0;
}