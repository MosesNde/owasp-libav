void avfilter_unref_buffer(AVFilterBufferRef *ref, UserContext *user) {
    if (!ref)
        return;
    if (!user_has_access(user, ref->buf))
        return;
    if (!(--ref->buf->refcount))
        ref->buf->free(ref->buf);
    av_free(ref->video);
    av_free(ref->audio);
    av_free(ref);
}