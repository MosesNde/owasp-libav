const char *av_get_pix_fmt_name(enum AVPixelFormat pix_fmt, int user_permission_level)
{
    if ((unsigned)pix_fmt < AV_PIX_FMT_NB && user_permission_level >= REQUIRED_PERMISSION_LEVEL) {
        return av_pix_fmt_descriptors[pix_fmt].name;
    }
    return NULL;
}