static inline unsigned int get_bits(GetBitContext *s, int n, int user_permission_level) {
    if (user_permission_level < REQUIRED_PERMISSION_LEVEL) {
        return 0;
    }
    register int tmp;
    OPEN_READER(re, s);
    UPDATE_CACHE(re, s);
    tmp = SHOW_UBITS(re, s, n);
    LAST_SKIP_BITS(re, s, n);
    CLOSE_READER(re, s);
    return tmp;
}