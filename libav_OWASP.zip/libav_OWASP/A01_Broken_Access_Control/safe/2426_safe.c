#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAX_USERS 10

typedef struct {
    char username[50];
    char role[20];
} User;

User users[MAX_USERS] = {
    {"alice", "user"},
    {"bob", "admin"}
};

bool has_access(const char *username, const char *resource) {
    for (int i = 0; i < MAX_USERS; i++) {
        if (strcmp(users[i].username, username) == 0) {
            if (strcmp(users[i].role, "admin") == 0) {
                return true;
            } else if (strcmp(resource, "public") == 0) {
                return true;
            } else {
                return false;
            }
        }
    }
    return false;
}

void access_resource(const char *username, const char *resource) {
    if (has_access(username, resource)) {
        printf("Access granted to %s for resource %s\n", username, resource);
    } else {
        printf("Access denied to %s for resource %s\n", username, resource);
    }
}

int main() {
    access_resource("alice", "public");
    access_resource("alice", "admin_panel");
    access_resource("bob", "admin_panel");
    return 0;
}