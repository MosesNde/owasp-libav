int check_user_permission(int user_id, int resource_id) {
    if (user_id == resource_id) {
        return 1;
    }
    return 0;
}

void access_resource(int user_id, int resource_id) {
    if (!check_user_permission(user_id, resource_id)) {
        return;
    }
    
}

int main() {
    int user_id = 1;
    int resource_id = 1;
    access_resource(user_id, resource_id);
    return 0;
}