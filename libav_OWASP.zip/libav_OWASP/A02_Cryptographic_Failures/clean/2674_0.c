static void init_uni_ac_vlc(RLTable *rl, uint8_t *uni_ac_vlc_len){
    int i;
    for(i=0; i<128; i++){
        int level= i-64;
        int run;
        if (!level)
            continue;
        for(run=0; run<64; run++){
            int len, code;
            int alevel= FFABS(level);
            if (alevel > rl->max_level[0][run])
                code= 111;
            else
                code= rl->index_run[0][run] + alevel - 1;
            if (code < 111  ) {
                len=   rl->table_vlc[code][1]+1;
            } else {
                len=  rl->table_vlc[111 ][1]+6;
                if (alevel < 128) {
                    len += 8;
                } else {
                    len += 16;
                }
            }
            uni_ac_vlc_len [UNI_AC_ENC_INDEX(run, i)]= len;
        }
    }
}
